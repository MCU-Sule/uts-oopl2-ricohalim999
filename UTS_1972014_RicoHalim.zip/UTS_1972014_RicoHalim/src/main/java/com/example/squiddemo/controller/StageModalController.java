/**
 * Rico Halim 1972014
 */
package com.example.squiddemo.controller;

import com.example.squiddemo.DAO.HutangDao;
import com.example.squiddemo.DAO.PlayerDao;
import com.example.squiddemo.entity.Hutang;
import com.example.squiddemo.entity.Player;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class StageModalController {
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNama;
    @FXML
    private TextField txtUmur;
    @FXML
    private TextField txtKeahlian;
    @FXML
    private final HutangDao iDao = new HutangDao();
    public PlayerDao cDao = new PlayerDao();
    private final ObservableList<Hutang> iList = iDao.showData();
    private final ObservableList<Player> cList = cDao.showData();
    private SquidController mainController;
    private final Alert alert = new Alert(Alert.AlertType.ERROR);
    private void okbtn(ActionEvent actionEvent) {
        if (txtId.getText().isEmpty() || txtNama.getText().isEmpty()||txtUmur.getText().isEmpty()||txtKeahlian.getText().isEmpty()) {
            alert.setHeaderText("ERROR");
            alert.setContentText("Please fill all the blanks!");
            alert.show();
        } else if (cek(Integer.parseInt(txtId.getText())) == -1) {
            Player c = new Player(Integer.parseInt(txtId.getText()), txtNama.getText(),txtUmur.getText(),txtKeahlian.getText());
            mainController.cDao.addData(c);
            mainController.getClass().componentType();

            reset();
        } else {
            alert.setHeaderText("ERROR");
            alert.setContentText("Duplicate Data");
            alert.show();
        }
    }
    private int cek(int id) {
        int x = -1;
        for (int i = 0; i < iList.size(); i++) {
            if (iList.get(i).getId()==id) {
                x = i;
            }
        }
        return x;
    }
    public void setMainController(SquidController mainController){
        this.mainController = mainController;
        mainController.setItems(mainController.getClass());
    }
    @FXML
    private void cancelbtn(ActionEvent actionEvent) {
        Platform.exit();
    }
}
