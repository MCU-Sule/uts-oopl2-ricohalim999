/**
 * Rico Halim 1972014
 */
package com.example.squiddemo.DAO;

import com.example.squiddemo.entity.Player;
import com.example.squiddemo.entity.Hutang;
import com.example.squiddemo.utility.JDBCConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HutangDao implements daoInterface<Hutang> {
    @Override
    public int addData(Hutang data) {
        int result = 0;
        try {
            String query = "INSERT INTO hutang (Id,pemberiUtang,jumlah,player_id) values(?,?,?,?)";
            PreparedStatement ps;
            ps = JDBCConnection.getConnection().prepareStatement(query);
            ps.setInt(1, data.getId());
            ps.setString(2, data.getPemberiUtang());
            ps.setDouble(3, data.getJumlah());
            ps.setInt(4, data.getPlayer_id());

            result = ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public int delData(Hutang data) {
        int result = 0;
        try {
            Connection con;
            con=JDBCConnection.getConnection();
            con.setAutoCommit(false);
            String query = "DELETE FROM hutang  WHERE Id=?";
            PreparedStatement ps;
            ps = con.prepareStatement(query);
            ps.setInt(1, data.getId());
            result = ps.executeUpdate();
            if (result !=0){
                con.commit();
            }else{
                con.rollback();
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public int updateData(Hutang data) {
        int result = 0;
        try {
            Connection con;
            con=JDBCConnection.getConnection();
            con.setAutoCommit(false);
            String query = "UPDATE hutang set pemberiUtang=?,jumlah=?,player_id=? WHERE Id=?";
            PreparedStatement ps;
            ps = con.prepareStatement(query);
            ps.setInt(5, data.getId());
            ps.setString(1, data.getPemberiUtang());
            ps.setDouble(2, data.getJumlah());
            ps.setInt(3, data.getPlayer_id());
            result = ps.executeUpdate();
            if (result !=0){
                con.commit();
            }else{
                con.rollback();
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public ObservableList<Hutang> showData() {
        ObservableList<Hutang> uList = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM hutang INNER JOIN player on player.id=hutang.player_id";
            PreparedStatement ps;
            ps = JDBCConnection.getConnection().prepareStatement(query);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                int Id= res.getInt("Id");
                String nama = res.getString("name");
                Double price = res.getDouble("price");
                String player = res.getString("category.name");
                String d = res.getString("description");
                uList.add(new Hutang(Id,hutangTerhadap,jumlah));
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return uList;
    }
}