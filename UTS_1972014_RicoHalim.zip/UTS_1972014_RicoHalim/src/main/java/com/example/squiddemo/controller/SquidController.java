/**
 * Rico Halim 1972014
 */
package com.example.squiddemo.controller;

import com.example.squiddemo.DAO.HutangDao;
import com.example.squiddemo.DAO.PlayerDao;
import com.example.squiddemo.entity.Hutang;
import com.example.squiddemo.entity.Player;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SquidController {
    @FXML
    private TableView tablePemain;
    @FXML
    private TableColumn colid;
    @FXML
    private TableColumn colnama;
    @FXML
    private TableColumn columur;
    @FXML
    private TableColumn colkemampuan;
    @FXML
    private ComboBox cmbPeserta;
    @FXML
    private TextField txtPemberiUtang;
    @FXML
    private TextField txtJumlah;
    @FXML
    private TableView tableHutang;
    @FXML
    private TableColumn colid_pemain;
    @FXML
    private TableColumn colhutangterhadap;
    @FXML
    private ObservableList<Player> players;
    private TableColumn colsejumlah;
    private final HutangDao iDao = new HutangDao();
    public PlayerDao cDao = new PlayerDao();
    private final Alert alert = new Alert(Alert.AlertType.ERROR);
    private void FetchAllData(){
        players.clear();

        try {
            players.addAll(PlayerDao.fetchAll());
        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }
    @FXML
    private void addbtn(ActionEvent actionEvent) {
        if (txtPemberiUtang.getText().isEmpty() || txtJumlah.getText().isEmpty() ||cmbPeserta.getSelectionModel().isEmpty()){
            alert.setHeaderText("ERROR");
            alert.setContentText("Please fill all the blanks");
            alert.show();
        }
        else{
            alert.setHeaderText("ERROR");
            alert.setContentText("Duplicate Text");
            alert.show();
        }
    }

    @FXML
    private void editbtn(ActionEvent actionEvent) {
        Hutang i = new Hutang(Integer.parseInt(txtJumlah.getText()), txtNama.getText(), Double.parseDouble(txtPrice.getText()), combo1.getSelectionModel().getSelectedItem(), txtDescription.getText());
        if (txtPemberiUtang.getText().isEmpty() || txtJumlah.getText().isEmpty() ||cmbPeserta.getSelectionModel().isEmpty()){
            alert.setHeaderText("ERROR");
            alert.setContentText("Please fill all the blanks");
            alert.show();
        }else{
            iDao.updateData(i);

            txtJumlah.setEditable(true);
            txtPemberiUtang.setDisable(true);
            cmbPeserta.setDisable(true);

        }
    }

    @FXML
    private void hapushutang(ActionEvent actionEvent) {
        txtJumlah.clear();
        txtPemberiUtang.clear();
    }


    private void hapusbtn(ActionEvent actionEvent) {
        txtPemberiUtang.clear();
        txtJumlah.clear();
    }
    @FXML
    private void OnTableSelected(MouseEvent mouseEvent) {
        int selected = tablePemain.getSelectionModel().getSelectedIndex();
        if(selected > -1){
            if(!players.isEmpty()) {
                //set textField text
                editbtn().setDisable(false);
                hapusbtn().setDisable(false);
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("The table is empty!");
                alert.show();
            }
        }

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        PlayerDao = new PlayerDao();

        cmbPeserta(FXCollections.observableArrayList());

        FetchAllData();

        Reset();

        colid.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getId()).asObject());
        colnama.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNama()));
        columur.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getUmur()).asObject());
        colkemampuan.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getKeahlian()));
        tablePemain.setItems(players);

        cmbPeserta.setItems(players);
    }
}
