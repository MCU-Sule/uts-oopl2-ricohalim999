/**
 * Rico Halim 1972014
 */
package com.example.squiddemo.DAO;

import com.example.squiddemo.entity.Player;
import com.example.squiddemo.utility.JDBCConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayerDao implements daoInterface<Player> {
    @Override
    public int addData(Player data) {
        int result = 0;
        try {
            String query = "INSERT INTO category (id,name) values(?,?)";
            PreparedStatement ps;
            ps = JDBCConnection.getConnection().prepareStatement(query);
            ps.setInt(1, data.getId());
            ps.setString(2, data.getName());
            result = ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }

    @Override
    public int delData(Player data) {
        return 0;
    }

    @Override
    public int updateData(Player data) {
        return 0;
    }

    @Override
    public ObservableList<Player> showData() {
        ObservableList<Player> cList = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM category";
            PreparedStatement ps;
            ps = JDBCConnection.getConnection().prepareStatement(query);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                int Id = res.getInt("id");
                int umur = res.getInt("umur");
                String nama = res.getString("name");
                String keahlian=res.getString("keahlian");
                cList.add(new Player(Id, umur, nama, keahlian));
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return cList;
    }
}