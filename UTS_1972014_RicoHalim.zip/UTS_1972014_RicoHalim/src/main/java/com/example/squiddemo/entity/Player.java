/**
 * Rico Halim 1972014
 */
package com.example.squiddemo.entity;

public class Player {
    private int Id,Umur;
    private String Nama,Keahlian;
    private Hutang Hutang;
    public Player() {
    }

    public Player(int id, int umur, String nama, String keahlian, com.example.squiddemo.entity.Hutang hutang) {
        Id = id;
        Umur = umur;
        Nama = nama;
        Keahlian = keahlian;
        Hutang = hutang;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getUmur() {
        return Umur;
    }

    public void setUmur(int umur) {
        Umur = umur;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getKeahlian() {
        return Keahlian;
    }

    public void setKeahlian(String keahlian) {
        Keahlian = keahlian;
    }

    @Override
    public String toString() {
        return Nama;
    }
}
